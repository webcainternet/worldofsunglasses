<?php
// Text
$_['text_approve_subject']      = '%s - Sua conta de afiliado foi aprovada!';
$_['text_approve_welcome']      = 'Obrigado por se cadastar no Programa de afiliados da loja %s!';
$_['text_approve_login']        = 'Sua conta foi aprovada, agora você pode acessar a sua conta em nosso Programa de afiliados utilizando o seu e-mail e sua senha através de nossa loja:';
$_['text_approve_services']     = 'Ao acessar sua conta de afiliado, você será capaz de gerar links dos produtos para divulgar em seu site ou blog, controlar pagamentos de comissões e editar as informações de sua conta.';
$_['text_approve_thanks']       = 'Atenciosamente,';
$_['text_transaction_subject']  = '%s - Pagamento de comissão';
$_['text_transaction_received'] = 'Você recebeu %s de comissão.';
$_['text_transaction_total']    = 'O total de sua comissão é: %s.';