<?php
// Text
$_['text_subject']  = '%s - Solicitação de nova de senha';
$_['text_greeting'] = 'Foi solicitada uma nova senha de acesso através da loja %s.';
$_['text_change']   = 'Para cadastrar sua nova senha, clique no link abaixo:';
$_['text_ip']       = 'O IP utilizado para fazer esta solicitação foi: %s';