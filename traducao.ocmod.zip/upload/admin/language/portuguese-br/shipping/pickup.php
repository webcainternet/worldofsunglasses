<?php
// Heading
$_['heading_title']    = 'Retirar na loja';

// Text
$_['text_shipping']    = 'Frete';
$_['text_success']     = 'Frete Retirar na loja modificado com sucesso!';
$_['text_edit']        = 'Configurações do frete Retirar na loja';

// Entry
$_['entry_geo_zone']   = 'Região geográfica';
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o frete Retirar na loja!';