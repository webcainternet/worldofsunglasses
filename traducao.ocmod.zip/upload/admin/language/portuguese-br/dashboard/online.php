<?php
// Heading
$_['heading_title'] = 'Clientes online';

// Text
$_['text_view']     = 'Ver mais...';