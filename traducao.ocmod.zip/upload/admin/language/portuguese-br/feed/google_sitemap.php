<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Alimentadores';
$_['text_success']     = 'Módulo Google Sitemap modificado com sucesso!';
$_['text_edit']        = 'Editando Google Sitemap';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_data_feed']  = 'URL';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Google Sitemap!';