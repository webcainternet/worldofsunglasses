<?php
// Heading
$_['heading_title']    = 'Botão de pagamento Paypal';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Botão de pagamento Paypal modificado com sucesso!';
$_['text_edit']        = 'Configurações do módulo Botão de pagamento Paypal';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o módulo Botão de pagamento Paypal!';