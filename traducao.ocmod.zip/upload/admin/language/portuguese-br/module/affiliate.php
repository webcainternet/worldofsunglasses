<?php
// Heading
$_['heading_title']    = 'Menu do afiliado';

$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Menu do afiliado modificado com sucesso!';
$_['text_edit']        = 'Configurações do módulo Menu do afiliado';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o módulo Menu do afiliado!';