<?php
// Heading
$_['heading_title']    = 'Pontos';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Pontos modificado com sucesso!';
$_['text_edit']        = 'Configurações dos Pontos';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os Pontos!';