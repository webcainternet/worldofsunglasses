<?php
// Text
$_['text_success'] = 'A API foi iniciada com sucesso';

// Error
$_['error_login']  = 'Atenção: Os dados de acesso não são válidos.';