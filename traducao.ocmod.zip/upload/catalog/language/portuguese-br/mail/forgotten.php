<?php
// Text
$_['text_subject']  = '%s - Nova senha';
$_['text_greeting'] = 'Uma nova senha foi solicitada através da loja %s.';
$_['text_password'] = 'Sua nova senha é:';
