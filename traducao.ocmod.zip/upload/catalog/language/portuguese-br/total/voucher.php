<?php
// Text
$_['text_voucher'] = 'Vale presentes (%s)';